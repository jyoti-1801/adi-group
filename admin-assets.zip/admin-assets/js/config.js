'use strict';

// JS global variables
let config = {
  colors: {
    primary: '#B02A2F',
    secondary: '#8592a3',
    success: '#71dd37',
    info: '#cecece',
    warning: '#ffab00',
    danger: '#ff3e1d',
    dark: '#233446',
    black: '#000',
    white: '#fff',
    body: '#f4f5fb',
    headingColor: '#B02A2F',
    axisColor: '#000000',
    borderColor: '#eceef1'
  }
};
